import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart';

String accessToken = "";

Future<void> fetchData() async {
  final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/posts/1'));

  if (response.statusCode == 200) {
    final Map<String, dynamic> data = json.decode(response.body);
    print('GET Response: $data');
  } else {
    print('Failed to load data. Status code: ${response.statusCode}');
  }
}


void postData() async {
  Dio dio = Dio();
  try {
    Response response = await dio.post(
      'http://13.213.157.20:5555/systemservice/oauth/token',
      data: {
        'grant_type': 'password',
        'username': 'zafrina',
        'password': '123456',
      },
      options: Options(
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Basic dG1zd2ViY2xpZW50OnRtc2luYWN0aW9u',
        },
      ),
    );

    if (response.statusCode == 200) {
      print('POST Response: ${response.data}');
      //Access Token
      accessToken = response.data['access_token'];
      print('My Access Token is: ${accessToken}');

    } else {
      print('Failed to post data. Status code: ${response.statusCode}');
      print('Response body: ${response.data}');
    }
  } catch (e) {
    print('Error during POST request: $e');
  }
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('API Communication in Flutter'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              ElevatedButton(
                onPressed: fetchData,
                child: Text('GET Data'),
              ),
              ElevatedButton(
                onPressed: postData,
                child: Text('POST Data'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

package api.com.example.apiintegretion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
